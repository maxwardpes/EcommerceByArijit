INSERT INTO PRODUCT (name,desc,brand,price,category,release_date,available,quantity) values
    ('tata nexon','nexon','tata',7500.00,'cars','2024-02-01',true,50),
    ('suzuki alto','alto','suzuki',6700.00,'cars','2023-03-01',true,50);
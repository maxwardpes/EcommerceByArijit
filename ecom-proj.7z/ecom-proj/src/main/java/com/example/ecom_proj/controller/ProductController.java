package com.example.ecom_proj.controller;

import com.example.ecom_proj.model.Product;
import com.example.ecom_proj.service.ProductService;
import lombok.experimental.PackagePrivate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/api")
public class ProductController {

    @Autowired
    ProductService service;

    @RequestMapping("/")
    public String greet(){
     return "hello!";
    }

    @GetMapping("/products")
    public ResponseEntity<List<Product>> getAllProducts(){

        return new ResponseEntity<>(service.getAllProducts(), HttpStatus.OK);
    }

    @GetMapping("/product/{id}")
    public Product getProduct(@PathVariable int id){
        return service.getProduct(id);
    }

    @PostMapping("/product")
    public  ResponseEntity<?> addProduct(@RequestPart Product product,
                                         @RequestPart MultipartFile imageFile){

        try{

            Product product1=service.addProduct(product,imageFile);
            return  new ResponseEntity<>(product1,HttpStatus.CREATED);
        }catch(Exception ex){
            return new ResponseEntity<>(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/product/{productId}/image")
    public ResponseEntity<byte[]> getImage(@PathVariable int productId){
        Product prod=service.getProduct(productId);
        byte[] imagebyte=prod.getImageData();

        return  ResponseEntity.ok().contentType(MediaType.valueOf(prod.getImageType())).body(imagebyte);

    }

    @PutMapping("/product/{id}")
    public ResponseEntity<String> updateProduct (@PathVariable int id, @RequestPart Product product,
                                                 @RequestPart MultipartFile imageFile) throws IOException {
        Product product1=service.updateProduct(id,product,imageFile);
        if(product1!=null)
        return new ResponseEntity<>("Updated",HttpStatus.OK);
        else
            return new ResponseEntity<>("Failed to Update",HttpStatus.BAD_REQUEST);

    }

    @DeleteMapping("/product/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable int id){
        service.deleteProduct(id);
        return  new ResponseEntity<>("Successfully Deleted",HttpStatus.OK);
    }

    @GetMapping("/products/search")
    public ResponseEntity<List<Product>> searchByKeyword(@RequestParam String keyword){
        List<Product> products=service.getProductsearchByKeyword(keyword);
        return new ResponseEntity<>(products,HttpStatus.FOUND);

    }


}
